﻿using MediatR;
using RentaDeVehiculos.LogicaDeNegocio.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentaDeVehiculos.LogicaDeNegocio.UseCases.Rentals.Commands.DeleteRentals;


public record DeleteRentalsCommand(int RentalId) : IRequest<int>;


